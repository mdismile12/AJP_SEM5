// Client side Program
// Client side program:-
import java.net.*;
import java.io.*;
class CliU
{
    public static void main(String[]args) throws Exception{
    while(true)
    {
        System.out.println("enter string");
        BufferedReader b1 = new BufferedReader(new InputStreamReader(System.in));
        InetAddress add = InetAddress.getLocalHost();
        DatagramSocket clis = new DatagramSocket();
        byte out[] = new byte[1024];
        byte in[] = new byte[1024];
        String str = b1.readLine();
        out = str.getBytes();
        DatagramPacket p1 = new DatagramPacket(out,out.length,add,1234);
        clis.send(p1);

        DatagramPacket p2 = new DatagramPacket(in,in.length);
        clis.receive(p2);
        String str2 = new String(p2.getData());
        System.out.println("Capital of the String will be:- "+str2);
        clis.close();
    }
    }
    
}